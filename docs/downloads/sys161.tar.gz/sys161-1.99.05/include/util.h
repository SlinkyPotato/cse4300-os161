
/*
 * Utility functions.
 *
 * domalloc calls smoke() if it fails.
 */

void *domalloc(size_t);
void dohexdump(const char *buf, size_t len);
