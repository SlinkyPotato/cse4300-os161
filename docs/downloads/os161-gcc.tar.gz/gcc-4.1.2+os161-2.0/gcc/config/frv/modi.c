int __modi (int a, int b)
{
  return a % b;
}
